package com.palletizer.alarm

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    @Volatile private var analyzing = false
    @Volatile private var lastAlarmText = ""
    @Volatile private var lastAlarmTime = 0L

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else status.text = "Cần cấp quyền camera để giám sát."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        status = TextView(this).apply { text = "Palletizer Alarm: sẵn sàng"; textSize = 18f; setTextColor(Color.BLACK) }
        previewView = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val startButton = Button(this).apply {
            text = "BẮT ĐẦU GIÁM SÁT"
            setOnClickListener {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
                else cameraPermission.launch(Manifest.permission.CAMERA)
            }
        }
        val testButton = Button(this).apply { text = "THỬ CHUÔNG"; setOnClickListener { soundAlarm() } }
        layout.addView(status); layout.addView(previewView); layout.addView(startButton); layout.addView(testButton)
        setContentView(layout)
        cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { analyzeImage(it) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                status.text = "Đang giám sát màn hình HMI..."
            } catch (e: Exception) { status.text = "Không mở được camera: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeImage(proxy: ImageProxy) {
        val mediaImage = proxy.image
        if (mediaImage == null || analyzing) { proxy.close(); return }
        analyzing = true
        val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val text = result.text
                runOnUiThread { status.text = if (text.isBlank()) "Chưa đọc được chữ. Hãy chỉnh camera rõ hơn." else "Đang giám sát HMI:\n$text" }
                val faultLine = text.lines().firstOrNull { line ->
                    val s = line.trim().lowercase()
                    !s.contains("no current alarm") && s.length >= 18 &&
                        listOf("fault", "alarm", "blocked", "error").any { s.contains(it) }
                }
                if (faultLine != null) {
                    val now = System.currentTimeMillis()
                    val normalized = faultLine.trim().lowercase()
                    if (normalized != lastAlarmText || now - lastAlarmTime > 15000L) {
                        lastAlarmText = normalized; lastAlarmTime = now
                        runOnUiThread { status.text = "⚠ PHÁT HIỆN LỖI:\n$faultLine" }
                        soundAlarm()
                    }
                }
            }
            .addOnFailureListener { runOnUiThread { status.text = "Đọc chữ thất bại. Hãy chỉnh camera." } }
            .addOnCompleteListener { analyzing = false; proxy.close() }
    }

    private fun soundAlarm() {
        try { ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 2000) } catch (_: Exception) {}
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
            else { @Suppress("DEPRECATION") vibrator.vibrate(1000) }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer.close()
        executor.shutdown()
    }
}
